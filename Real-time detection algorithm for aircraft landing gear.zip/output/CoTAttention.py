import numpy as np
import torch
from torch import flatten, nn
from torch.nn import functional as F
from PIL import Image
import torchvision.transforms as transforms
import matplotlib.pyplot as plt

class CoTAttention(nn.Module):

    def __init__(self, dim=512, kernel_size=3):
        super().__init__()
        self.dim = dim
        self.kernel_size = kernel_size

        # 扩展输入图像通道数为 512
        self.channel_expansion = nn.Conv2d(3, dim, kernel_size=1)

        self.key_embed = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=kernel_size, padding=kernel_size // 2, groups=4, bias=False),
            nn.BatchNorm2d(dim),
            nn.ReLU()
        )
        self.value_embed = nn.Sequential(
            nn.Conv2d(dim, dim, 1, bias=False),
            nn.BatchNorm2d(dim)
        )

        factor = 4
        self.attention_embed = nn.Sequential(
            nn.Conv2d(2 * dim, 2 * dim // factor, 1, bias=False),
            nn.BatchNorm2d(2 * dim // factor),
            nn.ReLU(),
            nn.Conv2d(2 * dim // factor, kernel_size * kernel_size * dim, 1)
        )

    def forward(self, x):
        x = self.channel_expansion(x)  # 扩展通道数
        bs, c, h, w = x.shape

        # 提取 key 和 value
        k1 = self.key_embed(x)  # 键嵌入，保持形状 bs, c, h, w
        v = self.value_embed(x)  # 值嵌入，保持原始形状 bs, c, h, w

        # 计算注意力映射
        y = torch.cat([k1, x], dim=1)  # 拼接 k1 和 x 作为输入，形状为 bs, 2c, h, w
        att = self.attention_embed(y)  # 生成注意力映射，形状为 bs, c*k*k, h, w

        # 重整形并计算注意力权重
        att = att.view(bs, c, self.kernel_size * self.kernel_size, h, w)
        # att = att.mean(2, keepdim=False)  # 去掉卷积核维度，形状为 bs, c, h, w

        # 应用 softmax 并与 v 相乘
        k2 = F.softmax(att, dim=-1) * v  # 加权注意力

        return k2  # 输出经过注意力加权的结果


def process_image(image_path):
    # 加载图片并进行预处理
    image = Image.open(image_path)
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    img_tensor = transform(image).unsqueeze(0)  # 添加批次维度
    return img_tensor

def post_process(tensor):
    # 只保留前 3 个通道（对应于 RGB）
    tensor = tensor[:, :3, :, :]  # 选择前 3 个通道 (batch, channels, height, width)

    # 将张量转换回 PIL 图片
    unloader = transforms.ToPILImage()
    tensor = tensor.squeeze(0)  # 移除批次维度
    tensor = tensor.cpu().clone()  # 克隆张量
    tensor = tensor * torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1) + torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)  # 反归一化
    tensor = torch.clamp(tensor, 0, 1)  # 保证数值在 [0, 1] 之间
    image = unloader(tensor)
    return image


img = r"C:/Users/101/Desktop/Real-time detection algorithm for aircraft landing gear/1_0403.jpg"
if __name__ == '__main__':
    # 加载并处理图片
    img_tensor = process_image("C:/Users/101/Desktop/Real-time detection algorithm for aircraft landing gear/1_0403.jpg")

    # 创建 CoTAttention 模块
    cot = CoTAttention(dim=512, kernel_size=3)

    # 将图片传入模型
    with torch.no_grad():
        output = cot(img_tensor)

    # 后处理并显示输出图片
    output_image = post_process(output)

    # 显示原图和处理后的图片
    original_image = Image.open("C:/Users/101/Desktop/Real-time detection algorithm for aircraft landing gear/1_0403.jpg")  # 使用图片的实际路径
    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1)
    plt.title("Original Image")
    plt.imshow(original_image)
    plt.axis('off')

    plt.subplot(1, 2, 2)
    plt.title("Processed Image")
    plt.imshow(output_image)
    plt.axis('off')

    plt.show()

    # output_image.save("processed_image.jpg")

    # # 保存处理后的图片
    output_image.save("C:/Users/101/Desktop/Real-time detection algorithm for aircraft landing gear/output/att.jpg")  # 保存路径为桌面上的 processed_image.jpg

